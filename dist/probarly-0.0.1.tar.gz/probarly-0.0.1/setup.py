from setuptools import setup

setup(
    name="probarly",
    version="0.0.1",
    description="Create beautiful, heavily customizable progress bars... probarly",
    url="http://github.com/phil-gates/probarly",
    author="Phil",
    author_email="mateopw10@gmail.com",
    license="MIT",
    packages=["probarly"],
    zip_safe=False,
)
